const { matrixChainOrderGreedy } = PacktDataStructuresAlgorithms;

const p = [10, 100, 5, 50, 1];
console.log(matrixChainOrderGreedy(p));
