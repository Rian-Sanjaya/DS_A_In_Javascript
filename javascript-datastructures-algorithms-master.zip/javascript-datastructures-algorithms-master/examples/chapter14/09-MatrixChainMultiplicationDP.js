const { matrixChainOrder } = PacktDataStructuresAlgorithms;

const p = [10, 100, 5, 50, 1];
console.log(matrixChainOrder(p));
