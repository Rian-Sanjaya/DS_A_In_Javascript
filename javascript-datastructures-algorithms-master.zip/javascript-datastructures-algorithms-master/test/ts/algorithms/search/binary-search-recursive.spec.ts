import { binarySearchRecursive } from '../../../../src/ts/index';
import { testSearchAlgorithm } from './search-algorithms-tests';

testSearchAlgorithm(binarySearchRecursive, 'Binary Search Recursive');

