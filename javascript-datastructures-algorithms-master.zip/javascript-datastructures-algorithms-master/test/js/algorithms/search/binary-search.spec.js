import { binarySearch } from '../../../../src/js/index';
import { testSearchAlgorithm } from './search-algorithms-tests';

testSearchAlgorithm(binarySearch, 'Binary Search');
